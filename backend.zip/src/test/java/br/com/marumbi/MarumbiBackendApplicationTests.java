package br.com.marumbi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarumbiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}

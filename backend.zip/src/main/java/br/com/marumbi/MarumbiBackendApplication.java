package br.com.marumbi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarumbiBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarumbiBackendApplication.class, args);
	}

}
